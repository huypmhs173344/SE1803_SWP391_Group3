



package model;



import java.util.*;
import java.lang.*;

public class Categories {
    int cid;
    String cname;

    public Categories() {
    }

    public Categories(int cid, String cname) {
        this.cid = cid;
        this.cname = cname;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
    
}
